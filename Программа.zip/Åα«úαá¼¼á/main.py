from statistics import mode


class tad1:

    def Add():
        print('Введите данные через пробел')
        a = input()
        s = '\n'+a
        f.write(s)

    def Edit():
        print('Введите индекс строки которую хотите редактировать')
        z = int(input())
        print("Напишите данные которыми хотите заменить существующие")
        a = input()+'\n'
        data = 0
        with open('tad.txt','r') as f:
            data = f.readlines()
        with open('tad.txt', 'w') as f:
            for line in data:
                if line.strip('\n') != data[z-1].strip('\n'):
                    f.write(line)
                else:
                    f.write(a)

    def Remowe():
        print('Введите индекс строки которую хотите удалить')
        z = int(input())
        data = 0
        with open('tad.txt','r') as f:
            data = f.readlines()
        with open('tad.txt', 'w') as f:
            for line in data:
                if line.strip('\n') != data[z-1].strip('\n'):
                    f.write(line)

class tad2:

    def otput():
        print("код читателя|фамилия|имя|отчество|№ читательского билета")
        f = open('tad1.txt', 'r')
        print(*f)
        f.close()


class tad3:

    def otput():
        print("код читателя|книги|дата выдачи")
        f = open('tad2.txt', 'r')
        print(*f)
        f.close()

while True:
    print('Выбирите таблицу\nКниги - 1\nЧитатели - 2\nВыдача - 3\nВыбирите запрос\nНаиболее читаемый автор - 4\n'
          'Выдачу книг по датам - 5\nВыход - 6')
    tad = int(input())
    if tad == 1:
        while True:
            print('код книги|название|автор|жанр|год издания')
            f = open('tad.txt','r+')
            print(*f)
            print('Добавить - 1 \nРедактировать - 2 \nУдалить - 3 \nВыход - 4')
            c = int(input())
            if c == 1:
                tad1.Add()
            elif c == 2:
                tad1.Edit()
            elif c == 3:
                tad1.Remowe()
            elif c == 4:
                break
    elif tad == 2:
        tad2.otput()
    elif tad == 3:
        tad3.otput()
    elif tad == 4:
        data = 0
        z = []
        x = []
        with open('tad.txt', 'r') as f:
            data = f.readlines()
        for i in data:
            z.append(i.split(' '))
        for i in z:
            x.append(i[2])
        print('Наиболее читаемый автор = ', mode(x),'\n')
    elif tad == 5:
        print('Выдача книг по дадам')
        data = 0
        z = []
        x = []
        c = []
        with open('tad2.txt', 'r') as f:
            data = f.readlines()
        for i in data:
            z.append(i.split(' '))
        for i in z:
            x.append(i[1])
            v = i[2]
            x.append(v[0:-1])
            if v[-1] == '\n':
                print(i[1], v[0:-1])
            else:
                print(i[1], v)
        print('\n')
    elif tad == 6:
        break